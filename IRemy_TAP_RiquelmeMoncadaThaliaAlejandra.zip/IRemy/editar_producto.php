<?php
session_start();
require 'conexion.php';
if ($_SESSION['usuario_rol'] != 1) { header("Location: dashboard.php"); exit(); }
$id = $_GET['id'];
$prod = $conexion->query("SELECT * FROM inventario WHERE id_producto = $id")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style> body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding-top: 2rem; } .card-glass { background: rgba(255,255,255,0.98); border-radius: 12px; padding: 2rem; max-width: 600px; margin: auto; } </style>
</head>
<body>
    <div class="container">
        <div class="card-glass">
            <h4 class="mb-4">Editar: <?php echo $prod['nombre_producto']; ?></h4>
            <form action="actualizar_producto.php" method="POST">
                <input type="hidden" name="id" value="<?php echo $prod['id_producto']; ?>">
                <div class="mb-3">
                    <label class="form-label">Nombre</label>
                    <input type="text" class="form-control" name="nombre" value="<?php echo $prod['nombre_producto']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Descripción</label>
                    <textarea class="form-control" name="descripcion"><?php echo $prod['descripcion']; ?></textarea>
                </div>
                <div class="row">
                    <div class="col-6 mb-3">
                        <label class="form-label">Stock</label>
                        <input type="number" class="form-control" name="stock" value="<?php echo $prod['stock']; ?>" required min="0">
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label">Precio</label>
                        <input type="number" class="form-control" name="precio" value="<?php echo $prod['precio_unitario']; ?>" min="0">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100">Actualizar</button>
                <a href="inventario.php" class="btn btn-link w-100 mt-2">Cancelar</a>
            </form>
        </div>
    </div>
</body>
</html>