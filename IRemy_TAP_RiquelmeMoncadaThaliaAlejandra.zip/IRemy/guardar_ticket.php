<?php
session_start();
require 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Recibir datos
    $cliente = $conexion->real_escape_string($_POST['rut_cliente']);
    $tecnico = $conexion->real_escape_string($_POST['rut_tecnico']);
    $desc = $conexion->real_escape_string($_POST['descripcion']);
    $estado = $conexion->real_escape_string($_POST['estado']);
    $sql = "INSERT INTO ticket (rut_cliente, rut_tecnico, descripcion_falla, estado) 
            VALUES ('$cliente', '$tecnico', '$desc', '$estado')";

    if ($conexion->query($sql) === TRUE) {
        echo "<script>alert('Ticket creado exitosamente.'); window.location.href='tickets.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conexion->error . "'); window.history.back();</script>";
    }

} else {
    header("Location: tickets.php");
}
?>