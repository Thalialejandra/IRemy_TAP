<?php
session_start();
require 'conexion.php';
if (!isset($_SESSION['usuario_rut'])) { header("Location: index.php"); exit(); }

// Traemos el ticket, pero "pegamos" los datos del Cliente y del Técnico para leer nombres, no RUTs.
$sql = "SELECT t.*, 
               c.nombres AS nom_cliente, c.apellidos AS ape_cliente, 
               u.nombres AS nom_tecnico 
        FROM ticket t 
        INNER JOIN cliente c ON t.rut_cliente = c.rut_cliente
        LEFT JOIN usuario u ON t.rut_tecnico = u.rut_usuario
        ORDER BY t.fecha_creacion DESC";

$resultado = $conexion->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Tickets - IRemy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; font-family: 'Segoe UI', sans-serif; }
        .card-glass { background: rgba(255, 255, 255, 0.98); border-radius: 12px; padding: 2rem; margin: 2rem 0; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .table-hover tbody tr:hover { background-color: #f8f9fa; }
        
        /* Colores para los estados */
        .badge-pendiente { background-color: #ffc107; color: #000; } /* Amarillo */
        .badge-proceso { background-color: #0d6efd; color: #fff; }   /* Azul */
        .badge-finalizado { background-color: #198754; color: #fff; } /* Verde */
        
        .btn-custom { border: 1px solid #dee2e6; color: #555; background: white; }
        .btn-custom:hover { background: #e9ecef; color: #000; }
    </style>
</head>
<body>

    <nav class="navbar navbar-dark bg-transparent pt-3 px-4">
        <a class="btn btn-outline-light btn-sm" href="dashboard.php"><i class="bi bi-arrow-left"></i> Volver</a>
        <span class="text-white fw-light ms-3">SOPORTE TÉCNICO / TICKETS</span>
    </nav>

    <div class="container">
        <div class="card-glass">
            
            <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                <h5 class="fw-bold text-secondary"><i class="bi bi-ticket-perforated me-2"></i>Tickets de trabajos</h5>
                <a href="crear_ticket.php" class="btn btn-dark btn-sm"><i class="bi bi-plus-lg me-1"></i>Nuevo ticket</a>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Número Ticket</th>
                            <th>Fecha</th>
                            <th>Cliente</th>
                            <th>Falla Reportada</th>
                            <th>Técnico</th>
                            <th class="text-center">Estado</th>
                            <th class="text-end">Gestión</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($resultado->num_rows > 0): ?>
                            <?php while($row = $resultado->fetch_assoc()): ?>
                                <tr>
                                    <td class="fw-bold text-muted">#<?php echo $row['id_ticket']; ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($row['fecha_creacion'])); ?></td>
                                    
                                    <td class="fw-bold text-primary">
                                        <?php echo $row['nom_cliente'] . " " . $row['ape_cliente']; ?>
                                    </td>
                                    
                                    <td>
                                        <?php echo substr($row['descripcion_falla'], 0, 40) . "..."; ?>
                                    </td>

                                    <td>
                                        <?php if($row['nom_tecnico']): ?>
                                            <small><i class="bi bi-person-gear me-1"></i><?php echo $row['nom_tecnico']; ?></small>
                                        <?php else: ?>
                                            <span class="text-muted small">Sin asignar</span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="text-center">
                                        <?php 
                                            $estado = $row['estado'];
                                            if($estado == 'Pendiente') echo '<span class="badge badge-pendiente">Pendiente</span>';
                                            elseif($estado == 'En Proceso') echo '<span class="badge badge-proceso">En Proceso</span>';
                                            else echo '<span class="badge badge-finalizado">Finalizado</span>';
                                        ?>
                                    </td>

                                    <td class="text-end">
                                        <a href="editar_ticket.php?id=<?php echo $row['id_ticket']; ?>" class="btn btn-custom btn-sm" title="Ver Detalles / Editar">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <?php if($_SESSION['usuario_rol'] == 1):?>
                                            <a href="eliminar_ticket.php?id=<?php echo $row['id_ticket']; ?>" class="btn btn-custom btn-sm ms-1" onclick="return confirm('¿Eliminar este ticket permanentemente?');">
                                                <i class="bi bi-trash3"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center py-5 text-muted">No hay tickets pendientes.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</body>
</html>