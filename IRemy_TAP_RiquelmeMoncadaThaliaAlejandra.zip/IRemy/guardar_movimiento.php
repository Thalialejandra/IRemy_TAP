<?php
session_start();
require 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $id_prod = $_POST['id_producto'];
    $tipo = $_POST['tipo_movimiento'];
    $cant = (int)$_POST['cantidad'];
    $rut_usuario = $_SESSION['usuario_rut'];
    
    if ($tipo == 'salida' || $tipo == 'merma') {
        $check = $conexion->query("SELECT stock FROM inventario WHERE id_producto = $id_prod");
        $actual = $check->fetch_assoc()['stock'];
        
        if ($actual < $cant) {
            echo "<script>alert('Error: No hay suficiente stock.'); window.history.back();</script>";
            exit();
        }
        $sql_update = "UPDATE inventario SET stock = stock - $cant WHERE id_producto = $id_prod";
    
    } else {
        $sql_update = "UPDATE inventario SET stock = stock + $cant WHERE id_producto = $id_prod";
    }

    if ($conexion->query($sql_update) === TRUE) {
        
        $sql_historial = "INSERT INTO movimiento_inventario (id_producto, rut_usuario, tipo_movimiento, cantidad) 
                          VALUES ($id_prod, '$rut_usuario', '$tipo', $cant)";
        $conexion->query($sql_historial);

        echo "<script>alert('Movimiento registrado con éxito.'); window.location.href='inventario.php';</script>";
    } else {
        echo "<script>alert('Error BD.'); window.history.back();</script>";
    }

} else {
    header("Location: inventario.php");
}
?>

