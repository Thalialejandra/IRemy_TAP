<?php
session_start();
require 'conexion.php';
if ($_SESSION['usuario_rol'] != 1) { header("Location: dashboard.php"); exit(); }

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $conexion->query("DELETE FROM inventario WHERE id_producto = $id");
    header("Location: inventario.php");
}
?>