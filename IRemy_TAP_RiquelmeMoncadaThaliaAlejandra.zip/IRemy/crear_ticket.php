<?php
session_start();
require 'conexion.php';
if (!isset($_SESSION['usuario_rut'])) { header("Location: index.php"); exit(); }

$sql_clientes = "SELECT rut_cliente, nombres, apellidos FROM cliente";
$res_clientes = $conexion->query($sql_clientes);
$sql_tecnicos = "SELECT rut_usuario, nombres, apellidos FROM usuario WHERE estado_cuenta = 1";
$res_tecnicos = $conexion->query($sql_tecnicos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nuevo Ticket - IRemy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding-top: 2rem; font-family: sans-serif; }
        .card-glass { background: rgba(255, 255, 255, 0.98); border-radius: 12px; padding: 2.5rem; margin: auto; max-width: 800px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card-glass">
            <h4 class="mb-4 fw-bold text-dark">Ingresar nuevo ticket</h4>
            
            <form action="guardar_ticket.php" method="POST">
                <div class="row g-3">
                    
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Cliente afectado <span class="text-danger">*</span></label>
                        <select class="form-select" name="rut_cliente" required>
                            <option value="" selected disabled>Seleccione un cliente...</option>
                            <?php while($c = $res_clientes->fetch_assoc()): ?>
                                <option value="<?php echo $c['rut_cliente']; ?>">
                                    <?php echo $c['nombres'] . " " . $c['apellidos']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <div class="form-text"><a href="crear_cliente.php">¿Cliente nuevo? - Creelo aquí</a></div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Técnico asignado</label>
                        <select class="form-select" name="rut_tecnico" required>
                            <option value="" selected disabled>Seleccione responsable...</option>
                            <?php while($t = $res_tecnicos->fetch_assoc()): ?>
                                <option value="<?php echo $t['rut_usuario']; ?>">
                                    <?php echo $t['nombres'] . " " . $t['apellidos']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-bold">Descripción de la falla <span class="text-danger">*</span></label>
                        <textarea class="form-control" name="descripcion" rows="4" placeholder="Describa el problema, equipo, síntomas..." required></textarea>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-bold">Estado inicial</label>
                        <select class="form-select bg-light" name="estado">
                            <option value="Pendiente">Pendiente</option>
                            <option value="En Proceso">En proceso</option>
                        </select>
                    </div>

                </div>

                <div class="d-flex justify-content-end mt-4 pt-3 border-top">
                    <a href="tickets.php" class="btn btn-outline-secondary me-2">Cancelar</a>
                    <button type="submit" class="btn btn-dark">Crear ticket</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>