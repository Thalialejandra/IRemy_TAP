<?php
session_start();
require 'conexion.php';

// Seguridad
if (!isset($_SESSION['usuario_rut'])) { header("Location: index.php"); exit(); }

if (!isset($_GET['rut'])) {
    header("Location: clientes.php");
    exit();
}

$rut_editar = $_GET['rut'];
$sql = "SELECT * FROM cliente WHERE rut_cliente = '$rut_editar'";
$resultado = $conexion->query($sql);
$cliente = $resultado->fetch_assoc();

if (!$cliente) {
    header("Location: clientes.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Cliente - IRemy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding-top: 2rem; }
        .card-glass { background: rgba(255, 255, 255, 0.98); border-radius: 12px; padding: 2rem; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .form-control[readonly] { background-color: #e9ecef; cursor: not-allowed; } /* Rut gris */
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card-glass">
                    <h4 class="mb-4">Editar Datos del Cliente</h4>
                    
                    <form action="actualizar_cliente.php" method="POST">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">RUT (No editable)</label>
                            <input type="text" class="form-control" name="rut" value="<?php echo $cliente['rut_cliente']; ?>" readonly>
                        </div>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nombres</label>
                                <input type="text" class="form-control" name="nombres" value="<?php echo $cliente['nombres']; ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Apellidos</label>
                                <input type="text" class="form-control" name="apellidos" value="<?php echo $cliente['apellidos']; ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Teléfono</label>
                                <input type="text" class="form-control" name="telefono" value="<?php echo $cliente['telefono']; ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" value="<?php echo $cliente['email']; ?>">
                            </div>
                            <div class="col-12 mb-4">
                                <label class="form-label">Dirección</label>
                                <input type="text" class="form-control" name="direccion" value="<?php echo $cliente['direccion']; ?>">
                            </div>
                        </div>

                        <div class="d-flex justify-content-end">
                            <a href="clientes.php" class="btn btn-outline-secondary me-2">Cancelar</a>
                            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</body>
</html>