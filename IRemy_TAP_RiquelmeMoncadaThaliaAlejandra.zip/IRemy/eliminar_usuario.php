<?php
session_start();
require 'conexion.php';
if (!isset($_SESSION['usuario_rut']) || $_SESSION['usuario_rol'] != 1) {
    header("Location: index.php");
    exit();
}
if (isset($_GET['rut'])) {
    
    $rut = $conexion->real_escape_string($_GET['rut']);

    // Evitar que el admin se elimine a sí mismo
    if ($rut == $_SESSION['usuario_rut']) {
        echo "<script>
                alert('Seguridad: No puedes desactivar tu propia cuenta mientras estás logueado.');
                window.location.href = 'usuarios.php';
              </script>";
        exit();
    }

    $sql_consulta = "SELECT estado_cuenta FROM usuario WHERE rut_usuario = '$rut'";
    $resultado = $conexion->query($sql_consulta);

    if ($resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();
        $estado_actual = $fila['estado_cuenta'];
        
        // Si es 1 pasa a 0, si es 0 pasa a 1
        $nuevo_estado = ($estado_actual == 1) ? 0 : 1;

        // Actualizar
        $sql_update = "UPDATE usuario SET estado_cuenta = $nuevo_estado WHERE rut_usuario = '$rut'";
        
        if ($conexion->query($sql_update) === TRUE) {
            $mensaje = ($nuevo_estado == 0) ? "Usuario desactivado correctamente." : "Usuario reactivado correctamente.";
            echo "<script>
                    alert('$mensaje');
                    window.location.href = 'usuarios.php';
                  </script>";
        } else {
            echo "<script>alert('Error al cambiar estado.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Usuario no encontrado.'); window.location.href = 'usuarios.php';</script>";
    }

} else {
    header("Location: usuarios.php");
}
?>