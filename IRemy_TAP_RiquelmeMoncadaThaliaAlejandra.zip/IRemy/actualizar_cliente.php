<?php
session_start();
require 'conexion.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $rut = $conexion->real_escape_string($_POST['rut']);
    $nombres = $conexion->real_escape_string($_POST['nombres']);
    $apellidos = $conexion->real_escape_string($_POST['apellidos']);
    $telefono = $conexion->real_escape_string($_POST['telefono']);
    $direccion = $conexion->real_escape_string($_POST['direccion']);
    $email = $conexion->real_escape_string($_POST['email']);
    $sql = "UPDATE cliente SET 
            nombres = '$nombres',
            apellidos = '$apellidos',
            telefono = '$telefono',
            direccion = '$direccion',
            email = '$email'
            WHERE rut_cliente = '$rut'";

    if ($conexion->query($sql) === TRUE) {
        echo "<script>
                alert('Cliente actualizado correctamente.');
                window.location.href = 'clientes.php';
              </script>";
    } else {
        echo "<script>
                alert('Error al actualizar: " . $conexion->error . "');
                window.history.back();
              </script>";
    }

} else {
    header("Location: clientes.php");
}
?>