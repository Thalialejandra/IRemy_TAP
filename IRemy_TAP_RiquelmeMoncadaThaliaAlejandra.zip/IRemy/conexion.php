<?php 
$servidor = "127.0.0.1"; 
$usuario = "root";
$password = "";
$base_datos = "bd_iremy";
$puerto = 3307;

// Creación de conexión
$conexion = new mysqli($servidor, $usuario, $password, $base_datos, $puerto);

// Verificación de conexión:
if ($conexion->connect_error) { 
    die("Error de conexión: " . $conexion->connect_error);
}

$conexion->set_charset("utf8mb4");

// echo "Conexión exitosa con la base de datos";
?>

