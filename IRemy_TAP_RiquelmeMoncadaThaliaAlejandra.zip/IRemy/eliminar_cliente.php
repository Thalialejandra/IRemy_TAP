<?php
session_start();
require 'conexion.php';
if (!isset($_SESSION['usuario_rut']) || $_SESSION['usuario_rol'] != 1) {
    echo "<script>alert('No tienes permisos para borrar clientes.'); window.location.href='clientes.php';</script>";
    exit();
}

if (isset($_GET['rut'])) {
    
    $rut = $conexion->real_escape_string($_GET['rut']);

    // IMPORTANTE: Si el cliente tiene tickets, la base de datos dará error (por seguridad).
    // Usamos 'try-catch' para capturar ese error y explicarlo al usuario.
    
    $sql = "DELETE FROM cliente WHERE rut_cliente = '$rut'";

    try {
        if ($conexion->query($sql) === TRUE) {
            echo "<script>
                    alert('Cliente eliminado correctamente.');
                    window.location.href = 'clientes.php';
                  </script>";
        }
    } catch (mysqli_sql_exception $e) {
        // Este bloque se ejecuta si la base de datos rechaza el borrado
        echo "<script>
                alert('NO SE PUEDE BORRAR: Este cliente tiene Tickets asociados. Debes borrar los tickets primero .');
                window.location.href = 'clientes.php';
              </script>";
    }

} else {
    header("Location: clientes.php");
}
?>