<?php
session_start();
if (!isset($_SESSION['usuario_rut'])) {
    header("Location: index.php");
    exit();
}
// Aquí no restringimos por rol, porque los Técnicos también deberían poder crear clientes.
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Cliente - IRemy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card-glass {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 2.5rem;
            margin-top: 2rem;
            margin-bottom: 2rem;
        }
        .btn-primary-custom {
            background-color: #4a5568; border-color: #4a5568; color: white;
        }
        .btn-primary-custom:hover { background-color: #2d3748; }
    </style>
</head>
<body>

    <nav class="navbar navbar-dark bg-transparent pt-3 px-4">
        <span class="text-white fw-light">CLIENTES / NUEVO REGISTRO IREMY</span>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card-glass">
                    
                    <div class="d-flex align-items-center mb-4 border-bottom pb-3">
                        <div class="me-3 text-secondary fs-4"><i class="bi bi-person-vcard"></i></div>
                        <div>
                            <h5 class="fw-bold text-dark mb-0">Ficha de cliente</h5>
                            <small class="text-muted">Ingrese los datos para contactar al cliente</small>
                        </div>
                    </div>

                    <form action="guardar_cliente.php" method="POST">
                        <div class="row g-3">
                            
                            <div class="col-md-6">
                                <label class="form-label fw-bold">RUT Cliente <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="rut" name="rut" placeholder="Ej: 77.123.456-1" required maxlength="12">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-bold">Teléfono contacto</label>
                                <input type="text" class="form-control" name="telefono" placeholder="+56 9...">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-bold">Nombres / Razón social <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="nombres" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-bold">Apellidos (Opcional)</label>
                                <input type="text" class="form-control" name="apellidos" placeholder="Si es empresa, dejar en blanco">
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-bold">Dirección / Ubicación</label>
                                <input type="text" class="form-control" name="direccion" placeholder="Calle, número, comuna...">
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-bold">Correo electrónico</label>
                                <input type="email" class="form-control" name="email" placeholder="contacto@cliente.cl">
                            </div>

                        </div>

                        <div class="d-flex justify-content-end mt-4 pt-3 border-top">
                            <a href="clientes.php" class="btn btn-outline-secondary me-2">Cancelar</a>
                            <button type="submit" class="btn btn-primary-custom">
                                <i class="bi bi-save me-2"></i>Guardar 
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('rut').addEventListener('blur', function(e) {
            let rut = e.target.value.replace(/\D/g, '');
            if (rut.length >= 7) {
                let rutFmt = rut.slice(0, -1) + '-' + rut.slice(-1);
                rutFmt = rutFmt.replace(/(\d{2})(\d{3})(\d{3})/, '$1.$2.$3');
                e.target.value = rutFmt;
            }
        });
    </script>
</body>
</html>