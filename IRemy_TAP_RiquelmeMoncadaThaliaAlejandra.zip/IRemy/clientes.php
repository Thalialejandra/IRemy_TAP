<?php
session_start();
require 'conexion.php';

// Seguridad: Validar sesión (Cualquier rol puede VER clientes, pero solo algunos editar)
if (!isset($_SESSION['usuario_rut'])) {
    header("Location: index.php");
    exit();
}

// Consulta: Traer todos los clientes
$sql = "SELECT * FROM cliente";
$resultado = $conexion->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión Clientes - IRemy</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .card-glass {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            padding: 2rem;
            margin-top: 2rem;
            margin-bottom: 2rem;
        }

        .table-hover tbody tr:hover { background-color: #f8f9fa; }
        
        .table thead th {
            font-weight: 600;
            color: #555;
            border-bottom: 2px solid #eee;
            background: transparent;
        }

        .btn-icon {
            border: 1px solid #dee2e6;
            color: #495057;
            background: white;
            padding: 0.25rem 0.5rem;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .btn-icon:hover {
            background-color: #e9ecef;
            color: #212529;
            border-color: #adb5bd;
        }

        .btn-primary-custom {
            background-color: #4a5568;
            border-color: #4a5568;
            color: white;
        }
        .btn-primary-custom:hover {
            background-color: #2d3748;
            border-color: #2d3748;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-dark bg-transparent pt-3 px-4">
        <a class="btn btn-outline-light btn-sm" href="dashboard.php">
            <i class="bi bi-arrow-left"></i> Volver
        </a>
        <span class="text-white fw-light ms-3" style="letter-spacing: 1px;">CARTERA DE CLIENTES - IREMY</span>
    </nav>

    <div class="container">
        
        <div class="card-glass">
            
            <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                <h5 class="text-secondary fw-bold mb-0">
                    <i class="bi bi-building me-2"></i>Directorio de clientes
                </h5>
                <a href="crear_cliente.php" class="btn btn-primary-custom btn-sm">
                    <i class="bi bi-plus-lg me-1"></i>Nuevo cliente
                </a>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>RUT</th>
                            <th>Razón Social / Nombre</th>
                            <th>Contacto</th>
                            <th>Dirección</th>
                            <th>Email</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php if ($resultado->num_rows > 0): ?>
                            <?php while($fila = $resultado->fetch_assoc()): ?>
                                <tr>
                                    <td class="fw-bold text-secondary"><?php echo $fila['rut_cliente']; ?></td>
                                    
                                    <td>
                                        <div class="fw-bold"><?php echo $fila['nombres'] . " " . $fila['apellidos']; ?></div>
                                    </td>
                                    
                                    <td>
                                        <?php if($fila['telefono']): ?>
                                            <small class="d-block text-muted">
                                                <i class="bi bi-telephone me-1"></i><?php echo $fila['telefono']; ?>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="small text-muted"><?php echo $fila['direccion']; ?></td>
                                    <td class="small text-primary"><?php echo $fila['email']; ?></td>

                                    <td class="text-end">
                                        <a href="editar_cliente.php?rut=<?php echo $fila['rut_cliente']; ?>" 
                                           class="btn btn-icon btn-sm" 
                                           title="Editar Información">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        
                                        <?php if($_SESSION['usuario_rol'] == 1): ?>
                                            <a href="eliminar_cliente.php?rut=<?php echo $fila['rut_cliente']; ?>" 
                                               class="btn btn-icon btn-sm ms-1" 
                                               title="Eliminar Cliente"
                                               onclick="return confirm('ATENCIÓN: ¿Seguro que desea eliminar este cliente? Se podrían perder historiales de tickets.');">
                                                <i class="bi bi-trash3"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-5">
                                    <i class="bi bi-folder2-open fs-1 d-block mb-2"></i>
                                    No hay clientes registrados
                                </td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>