<?php
session_start();
require 'conexion.php';

// Seguridad básica
if (!isset($_SESSION['usuario_rut'])) {
    header("Location: index.php");
    exit();
}

$rol = $_SESSION['usuario_rol']; // 1=Admin, 2=Técnico

// Traemos todo el inventario
$sql = "SELECT * FROM inventario ORDER BY nombre_producto ASC";
$resultado = $conexion->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inventario - IRemy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; font-family: 'Segoe UI', sans-serif; }
        .card-glass { background: rgba(255, 255, 255, 0.98); border-radius: 12px; padding: 2rem; margin: 2rem 0; }
        .stock-bajo { color: #dc3545; font-weight: bold; } 
        .stock-alerta { color: #faf605; font-weight: bold; } 
        .stock-ok { color: #198754; font-weight: bold; }   
        .btn-icon { border: 1px solid #dee2e6; background: white; padding: 4px 8px; border-radius: 5px; color: #555; }
    </style>
</head>
<body>

    <nav class="navbar navbar-dark bg-transparent pt-3 px-4">
        <a class="btn btn-outline-light btn-sm" href="dashboard.php"><i class="bi bi-arrow-left"></i> Volver</a>
        <span class="text-white fw-light ms-3">LOGÍSTICA / INVENTARIO IREMY</span>
    </nav>

    <div class="container">
        <div class="card-glass">
            
            <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                <div>
                    <h5 class="fw-bold text-secondary mb-1"><i class="bi bi-box-seam me-2"></i>Control de stock</h5>
                    <a href="historial.php" class="text-decoration-none small text-primary fw-bold">
                        <i class="bi bi-clock-history"></i> Ver Informe de movimientos
                    </a>
                </div>
                
                <?php if($rol == 1): ?>
                    <a href="crear_producto.php" class="btn btn-dark btn-sm"><i class="bi bi-plus-lg me-1"></i>Nuevo producto</a>
                <?php endif; ?>
            </div>
<form method="GET" class="mb-3">
    <div class="input-group">
        <span class="input-group-text bg-white">
            <i class="bi bi-search"></i>
        </span>
        <input 
            type="text"
            name="buscar"
            class="form-control"
            placeholder="Buscar producto por nombre..."
            value="<?php echo $_GET['buscar'] ?? ''; ?>">
        <?php if(!empty($_GET['buscar'])): ?>
            <a href="inventario.php" class="btn btn-outline-secondary">Limpiar</a>
        <?php endif; ?>
    </div>
</form>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Producto</th>
                            <th class="text-center">Stock actual</th>
                            <th class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($resultado->num_rows > 0): ?>
                            <?php while($row = $resultado->fetch_assoc()): ?>
                                <tr>
                                    <td class="text-muted small">#<?php echo $row['id_producto']; ?></td>
                                    <td>
                                        <div class="fw-bold"><?php echo $row['nombre_producto']; ?></div>
                                        <small class="text-muted"><?php echo $row['descripcion']; ?></small>
                                    </td>
                                    
                                    <td class="text-center">
                                        <?php if($row['stock'] < 5): ?>
                                            <span class="stock-bajo"><i class="bi bi-exclamation-circle me-1"></i> <?php echo $row['stock']; ?></span>
                                        <?php else: ?>
                                            <span class="stock-ok"><?php echo $row['stock']; ?></span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="text-center">
                                        <a href="gestionar_stock.php?id=<?php echo $row['id_producto']; ?>" class="btn btn-primary btn-sm" title="Registrar Entrada/Salida/Merma">
                                            <i class="bi bi-arrow-left-right me-1"></i> Movimientos
                                        </a>

                                        <?php if($rol == 1): ?>
                                            <a href="editar_producto.php?id=<?php echo $row['id_producto']; ?>" class="btn btn-icon ms-2" title="Editar Ficha"><i class="bi bi-pencil"></i></a>
                                            <a href="eliminar_producto.php?id=<?php echo $row['id_producto']; ?>" class="btn btn-icon ms-1" onclick="return confirm('¿Eliminar producto?');" title="Eliminar"><i class="bi bi-trash3"></i></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="4" class="text-center py-5 text-muted">No hay productos registrados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>