<?php
session_start();
require 'conexion.php';

// Si no hay ID o sesión, fuera
if (!isset($_SESSION['usuario_rut']) || !isset($_GET['id'])) { header("Location: inventario.php"); exit(); }

$id = $_GET['id'];
$rut_usuario = $_SESSION['usuario_rut'];

// Datos del producto
$sql = "SELECT * FROM inventario WHERE id_producto = $id";
$res = $conexion->query($sql);
$prod = $res->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Movimiento de stock / Merma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding-top: 2rem; }
        .card-glass { background: rgba(255, 255, 255, 0.98); border-radius: 12px; padding: 2.5rem; max-width: 600px; margin: auto; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card-glass">
            <h4 class="mb-3 fw-bold">Gestionar: <?php echo $prod['nombre_producto']; ?></h4>
            <div class="alert alert-info">Stock actual: <strong><?php echo $prod['stock']; ?> unidades</strong></div>

            <form action="guardar_movimiento.php" method="POST">
                <input type="hidden" name="id_producto" value="<?php echo $prod['id_producto']; ?>">
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Tipo de acción</label>
                    <select class="form-select" name="tipo_movimiento" required>
                        <option value="" selected disabled>Seleccione...</option>
                        
                        <option value="salida">SALIDA - Asignación / Uso en terreno</option>
                        
                        <option value="merma">MERMA - Material dañado / Perdido</option>
                        
                        <option value="entrada">ENTRADA - Reposición de stock</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Cantidad</label>
                    <input type="number" class="form-control" name="cantidad" min="1" required placeholder="Ej: 1">
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-dark">Registrar movimiento</button>
                    <a href="inventario.php" class="btn btn-outline-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>