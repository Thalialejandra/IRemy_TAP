<?php
session_start();
require 'conexion.php'; // Conectamos a la BD

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rut = $conexion->real_escape_string($_POST['rut']);
    $nombres = $conexion->real_escape_string($_POST['nombres']);
    $apellidos = $conexion->real_escape_string($_POST['apellidos']);
    $telefono = $conexion->real_escape_string($_POST['telefono']);
    $direccion = $conexion->real_escape_string($_POST['direccion']);
    $email = $conexion->real_escape_string($_POST['email']);
    $consulta = "SELECT rut_cliente FROM cliente WHERE rut_cliente = '$rut'";
    $resultado = $conexion->query($consulta);

    if ($resultado->num_rows > 0) {
        // Si ya existe, avisamos y no guardamos nada
        echo "<script>
                alert('Error: Este cliente ya está registrado.');
                window.history.back();
              </script>";
        exit();
    }

    // Si no existe, lo guardamos
    $sql = "INSERT INTO cliente (rut_cliente, nombres, apellidos, telefono, direccion, email) 
            VALUES ('$rut', '$nombres', '$apellidos', '$telefono', '$direccion', '$email')";

    if ($conexion->query($sql) === TRUE) {
        echo "<script>
                alert('Cliente guardado correctamente.');
                window.location.href = 'clientes.php';
              </script>";
    } else {
        echo "<script>
                alert('Error al guardar: " . $conexion->error . "');
                window.history.back();
              </script>";
    }

} else {
    header("Location: clientes.php");
}
?>