<?php
session_start(); // Iniciar para saber qué borrar
session_unset(); // Limpiar variables
session_destroy(); // Destruir la sesión

// Mandar de vuelta al Login
header("Location: index.php");
exit();
?>