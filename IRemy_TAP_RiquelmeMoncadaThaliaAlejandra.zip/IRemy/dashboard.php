<?php
session_start();

if (!isset($_SESSION['usuario_rut'])) {
    header("Location: index.php");
    exit();
}

// Variables para usar en el HTML
$nombre = $_SESSION['usuario_nombre'];
$rol = $_SESSION['usuario_rol']; // 1=Admin, 2=Técnico
$rol_texto = ($rol == 1) ? "Administrador" : "Técnico en Terreno";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IRemy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body {
            background-color: #f0f2f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar-custom {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .card-menu {
            border: none;
            border-radius: 15px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
            height: 100%;
            background: white;
        }

        .card-menu:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(118, 75, 162, 0.2);
        }

        .icon-large {
            font-size: 2.5rem;
            color: #764ba2;
            margin-bottom: 10px;
        }

        .welcome-section {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">IRemy</a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav align-items-center">
                    <li class="nav-item me-3 text-white">
                        Hola, <strong><?php echo $nombre; ?></strong>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="btn btn-light btn-sm fw-bold text-primary">
                            <i class="bi bi-box-arrow-right"></i> Salir
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        
        <div class="welcome-section d-flex justify-content-between align-items-center">
            <div>
                <h4 class="mb-1">Panel de control</h4>
                <p class="text-muted mb-0">Rol: <span class="badge bg-primary"><?php echo $rol_texto; ?></span></p>
            </div>
            <div class="text-end text-muted">
                <small><?php echo date('d/m/Y'); ?></small>
            </div>
        </div>

        <div class="row g-4">
            
            <?php if($rol == 1): ?>
            <div class="col-md-4 col-sm-6">
                <div class="card p-4 card-menu text-center" onclick="window.location.href='usuarios.php'">
                    <div class="icon-large"><i class="bi bi-people-fill"></i></div>
                    <h5 class="fw-bold">Usuarios</h5>
                    <p class="text-muted small">Crear/administrar personal</p>
                </div>
            </div>
            <?php endif; ?>

            <div class="col-md-4 col-sm-6">
                <div class="card p-4 card-menu text-center" onclick="window.location.href='tickets.php'">
                    <div class="icon-large"><i class="bi bi-ticket-perforated-fill"></i></div>
                    <h5 class="fw-bold">Tickets</h5>
                    <p class="text-muted small">Ver y gestionar órdenes</p>
                </div>
            </div>

            <div class="col-md-4 col-sm-6">
                <div class="card p-4 card-menu text-center" onclick="window.location.href='clientes.php'">
                    <div class="icon-large"><i class="bi bi-briefcase-fill"></i></div>
                    <h5 class="fw-bold">Clientes</h5>
                    <p class="text-muted small">Directorio de empresas</p>
                </div>
            </div>

            <div class="col-md-4 col-sm-6">
                <div class="card p-4 card-menu text-center" onclick="window.location.href='inventario.php'">
                    <div class="icon-large"><i class="bi bi-box-seam-fill"></i></div>
                    <h5 class="fw-bold">Inventario</h5>
                    <p class="text-muted small">Stock, Asignación y Mermas</p>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>