<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['usuario_rut']) || $_SESSION['usuario_rol'] != 1) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['rut'])) {
    header("Location: usuarios.php");
    exit();
}

$rut_editar = $_GET['rut'];

$sql = "SELECT * FROM usuario WHERE rut_usuario = '$rut_editar'";
$resultado = $conexion->query($sql);

if ($resultado->num_rows > 0) {
    $usuario = $resultado->fetch_assoc();
} else {
    // Si el usuario no existe, volver a la lista
    header("Location: usuarios.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario - IRemy</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .card-glass {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            padding: 2.5rem;
            margin-top: 2rem;
            margin-bottom: 2rem;
        }

        .form-label {
            font-weight: 600;
            color: #495057;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }

        .form-control, .form-select {
            border-radius: 6px;
            border: 1px solid #ced4da;
            padding: 0.7rem 1rem;
        }

        .form-control[readonly] {
            background-color: #e9ecef;
            color: #6c757d;
            cursor: not-allowed;
        }

        .input-group-text {
            background: white;
            border-left: none;
            cursor: pointer;
            color: #6c757d;
        }
        .password-input { border-right: none; }
        
        .btn-primary-custom {
            background-color: #4a5568;
            border-color: #4a5568;
            color: white;
            padding: 0.6rem 1.5rem;
            font-weight: 500;
        }
        .btn-primary-custom:hover {
            background-color: #2d3748;
            border-color: #2d3748;
        }

        .btn-outline-custom {
            border-color: #cbd5e0;
            color: #4a5568;
            padding: 0.6rem 1.5rem;
        }
        .btn-outline-custom:hover {
            background-color: #f7fafc;
            color: #2d3748;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-dark bg-transparent pt-3 px-4">
        <span class="text-white fw-light" style="letter-spacing: 1px;">RRHH / EDICIÓN DE PERFIL</span>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                
                <div class="card-glass">
                    
                    <div class="d-flex align-items-center mb-4 border-bottom pb-3">
                        <div class="me-3 text-warning fs-4">
                            <i class="bi bi-pencil-square"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold text-dark mb-0">Editar Colaborador</h5>
                            <small class="text-muted">Modificando ficha de: <?php echo $usuario['nombres']; ?></small>
                        </div>
                    </div>

                    <form action="actualizar_usuario.php" method="POST">
                        
                        <div class="row g-4">
                            
                            <div class="col-md-6">
                                <label class="form-label">RUT Colaborador (Intransferible)</label>
                                <input type="text" class="form-control" name="rut" value="<?php echo $usuario['rut_usuario']; ?>" readonly>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="rol" class="form-label">Cargo / Rol</label>
                                <select class="form-select" id="rol" name="rol" required>
                                    <option value="1" <?php if($usuario['id_rol'] == 1) echo 'selected'; ?>>Administrador</option>
                                    <option value="2" <?php if($usuario['id_rol'] == 2) echo 'selected'; ?>>Técnico</option>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="nombres" class="form-label">Nombres</label>
                                <input type="text" class="form-control" id="nombres" name="nombres" value="<?php echo $usuario['nombres']; ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label for="apellidos" class="form-label">Apellidos</label>
                                <input type="text" class="form-control" id="apellidos" name="apellidos" value="<?php echo $usuario['apellidos']; ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label for="email" class="form-label">Correo Corporativo</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo $usuario['email']; ?>">
                            </div>

                            <div class="col-md-6">
                                <label for="telefono" class="form-label">Teléfono / Móvil</label>
                                <input type="text" class="form-control" id="telefono" name="telefono" value="<?php echo $usuario['telefono']; ?>">
                            </div>

                            <div class="col-md-12">
                                <label for="estado" class="form-label">Estado de la Cuenta</label>
                                <select class="form-select" id="estado" name="estado_cuenta">
                                    <option value="1" <?php if($usuario['estado_cuenta'] == 1) echo 'selected'; ?>>Activo (Acceso permitido)</option>
                                    <option value="0" <?php if($usuario['estado_cuenta'] == 0) echo 'selected'; ?>>Inactivo (Acceso denegado)</option>
                                </select>
                            </div>

                            <div class="col-12 border-top pt-3 mt-2">
                                <label for="pass" class="form-label">Cambiar Contraseña</label>
                                <div class="input-group">
                                    <input type="password" class="form-control password-input" id="pass" name="password" placeholder="Dejar en blanco para mantener la actual" minlength="6">
                                    <span class="input-group-text" onclick="togglePassword()">
                                        <i class="bi bi-eye-slash" id="toggleIcon"></i>
                                    </span>
                                </div>
                                <div class="form-text text-muted">Solo complete este campo si desea generar una nueva clave de acceso.</div>
                            </div>

                        </div> <div class="d-flex justify-content-end mt-5 pt-3">
                            <a href="usuarios.php" class="btn btn-outline-custom me-2">
                                Cancelar
                            </a>
                            <button type="submit" class="btn btn-primary-custom">
                                <i class="bi bi-check-circle me-2"></i>Guardar Cambios
                            </button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('pass');
            const toggleIcon = document.getElementById('toggleIcon');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('bi-eye-slash');
                toggleIcon.classList.add('bi-eye');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('bi-eye');
                toggleIcon.classList.add('bi-eye-slash');
            }
        }
    </script>
</body>
</html>