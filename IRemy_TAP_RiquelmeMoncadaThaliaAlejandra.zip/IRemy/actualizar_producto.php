<?php
session_start();
require 'conexion.php';
if ($_SESSION['usuario_rol'] != 1) { exit(); }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nombre = $conexion->real_escape_string($_POST['nombre']);
    $desc = $conexion->real_escape_string($_POST['descripcion']);
    $stock = (int)$_POST['stock'];
    $precio = (int)$_POST['precio'];

    $sql = "UPDATE inventario SET nombre_producto='$nombre', descripcion='$desc', stock=$stock, precio_unitario=$precio WHERE id_producto=$id";
    
    if ($conexion->query($sql)) {
        echo "<script>alert('Actualizado.'); window.location.href='inventario.php';</script>";
    } else {
        echo "<script>alert('Error.'); window.history.back();</script>";
    }
}
?>