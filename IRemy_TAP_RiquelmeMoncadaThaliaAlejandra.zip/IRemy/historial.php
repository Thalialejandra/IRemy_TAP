<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['usuario_rut'])) {
    header("Location: index.php");
    exit();
}

// LÓGICA DE FILTROS
$filtro_tipo = isset($_GET['filtro_tipo']) ? $_GET['filtro_tipo'] : '';
$filtro_usuario = isset($_GET['filtro_usuario']) ? $_GET['filtro_usuario'] : '';

// Construcción dinámica de la consulta SQL
$sql = "SELECT m.fecha_movimiento, m.tipo_movimiento, m.cantidad, 
               i.nombre_producto, 
               u.nombres, u.apellidos 
        FROM movimiento_inventario m
        INNER JOIN inventario i ON m.id_producto = i.id_producto
        INNER JOIN usuario u ON m.rut_usuario = u.rut_usuario
        WHERE 1=1";

if ($filtro_tipo != '') {
    $sql .= " AND m.tipo_movimiento = '$filtro_tipo'";
}
if ($filtro_usuario != '') {
    $sql .= " AND (u.nombres LIKE '%$filtro_usuario%' OR u.apellidos LIKE '%$filtro_usuario%')";
}

$sql .= " ORDER BY m.fecha_movimiento DESC";

$resultado = $conexion->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historial de movimientos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding-top: 2rem; }
        .card-glass { background: rgba(255, 255, 255, 0.98); border-radius: 12px; padding: 2rem; margin: 2rem auto; max-width: 1000px; }
        .badge-entrada { background-color: #198754; }
        .badge-salida  { background-color: #0d6efd; }
        .badge-merma   { background-color: #dc3545; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card-glass">
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold"><i class="bi bi-file-earmark-spreadsheet me-2"></i>Informe de registro</h4>
                <a href="inventario.php" class="btn btn-outline-secondary btn-sm">Volver</a>
            </div>

            <form method="GET" action="historial.php" class="row g-3 mb-4 p-3 bg-light rounded border">
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Filtrar por tipo:</label>
                    <select name="filtro_tipo" class="form-select form-select-sm">
                        <option value="">Todos los movimientos</option>
                        <option value="entrada" <?php if($filtro_tipo=='entrada') echo 'selected'; ?>>Entradas</option>
                        <option value="salida" <?php if($filtro_tipo=='salida') echo 'selected'; ?>>Asignación a trabajador</option>
                        <option value="merma" <?php if($filtro_tipo=='merma') echo 'selected'; ?>>Mermas</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Buscar por trabajador:</label>
                    <input type="text" name="filtro_usuario" class="form-control form-control-sm" placeholder="Nombre o Apellido..." value="<?php echo $filtro_usuario; ?>">
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary btn-sm w-100 me-2"><i class="bi bi-search"></i> Filtrar informe</button>
                    <a href="historial.php" class="btn btn-secondary btn-sm"><i class="bi bi-x-lg"></i></a>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Tipo</th>
                            <th>Producto</th>
                            <th class="text-center">Cant.</th>
                            <th>Responsable</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($resultado->num_rows > 0): ?>
                            <?php while($row = $resultado->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo date('d/m/Y H:i', strtotime($row['fecha_movimiento'])); ?></td>
                                    <td>
                                        <?php 
                                            $t = $row['tipo_movimiento'];
                                            if($t=='entrada') echo '<span class="badge badge-entrada">Entrada</span>';
                                            elseif($t=='salida') echo '<span class="badge badge-salida">Asignación</span>';
                                            else echo '<span class="badge badge-merma">Merma</span>';
                                        ?>
                                    </td>
                                    <td class="fw-bold"><?php echo $row['nombre_producto']; ?></td>
                                    <td class="text-center"><?php echo $row['cantidad']; ?></td>
                                    <td class="text-muted small text-uppercase"><?php echo $row['nombres'] . " " . $row['apellidos']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="text-center py-4 text-muted">No se encontraron registros con esos filtros.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</body>
</html>