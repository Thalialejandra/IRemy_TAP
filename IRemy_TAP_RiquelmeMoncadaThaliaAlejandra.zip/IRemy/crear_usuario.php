<?php
session_start();

// 1. Seguridad: Verificar sesión y permisos de Admin
if (!isset($_SESSION['usuario_rut']) || $_SESSION['usuario_rol'] != 1) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Usuario - IRemy</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .card-glass {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            padding: 2.5rem;
            margin-top: 2rem;
            margin-bottom: 2rem;
        }

        .form-label {
            font-weight: 600;
            color: #495057;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }

        .form-control, .form-select {
            border-radius: 6px;
            border: 1px solid #ced4da;
            padding: 0.7rem 1rem;
            transition: border-color 0.2s;
        }

        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        /* Estilo input group contraseña (igual al login) */
        .input-group-text {
            background: white;
            border-left: none;
            cursor: pointer;
            color: #6c757d;
        }
        .password-input { border-right: none; }
        
        .btn-primary-custom {
            background-color: #4a5568;
            border-color: #4a5568;
            color: white;
            padding: 0.6rem 1.5rem;
            font-weight: 500;
        }
        .btn-primary-custom:hover {
            background-color: #2d3748;
            border-color: #2d3748;
        }

        .btn-outline-custom {
            border-color: #cbd5e0;
            color: #4a5568;
            padding: 0.6rem 1.5rem;
        }
        .btn-outline-custom:hover {
            background-color: #f7fafc;
            color: #2d3748;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-dark bg-transparent pt-3 px-4">
        <span class="text-white fw-light" style="letter-spacing: 1px;">RRHH / ALTA DE PERSONAL IREMY</span>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                
                <div class="card-glass">
                    
                    <div class="d-flex align-items-center mb-4 border-bottom pb-3">
                        <div class="me-3 text-secondary fs-4">
                            <i class="bi bi-person-badge"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold text-dark mb-0">Formulario de Registro</h5>
                            <small class="text-muted">Complete la información del nuevo colaborador</small>
                        </div>
                    </div>

                    <form action="guardar_usuario.php" method="POST">
                        
                        <div class="row g-4">
                            
                            <div class="col-md-6">
                                <label for="rut" class="form-label">RUT Colaborador <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="rut" name="rut" placeholder="Ej: 12.345.678-9" maxlength="12" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="rol" class="form-label">Cargo / Rol <span class="text-danger">*</span></label>
                                <select class="form-select" id="rol" name="rol" required>
                                    <option value="" selected disabled>Seleccione una opción...</option>
                                    <option value="1">Administrador</option>
                                    <option value="2">Técnico</option>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="nombres" class="form-label">Nombres <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="nombres" name="nombres" placeholder="Ingrese nombres" required>
                            </div>

                            <div class="col-md-6">
                                <label for="apellidos" class="form-label">Apellidos <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="apellidos" name="apellidos" placeholder="Ingrese apellidos" required>
                            </div>

                            <div class="col-md-6">
                                <label for="email" class="form-label">Correo Corporativo</label> 
                                <input type="email" class="form-control" id="email" name="email" placeholder="tucorreo@iremy.cl">
                            </div>

                            <div class="col-md-6">
                                <label for="telefono" class="form-label">Teléfono</label>
                                <input type="text" class="form-control" id="telefono" name="telefono" placeholder="+56 9...">
                            </div>

                            <div class="col-12">
                                <label for="pass" class="form-label">Contraseña de Acceso <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <input type="password" class="form-control password-input" id="pass" name="password" placeholder="Defina una contraseña temporal" required minlength="6">
                                    <span class="input-group-text" onclick="togglePassword()">
                                        <i class="bi bi-eye-slash" id="toggleIcon"></i>
                                    </span>
                                </div>
                                <div class="form-text text-muted">Ingresa tu clave</div>
                            </div>

                        </div> <div class="d-flex justify-content-end mt-5 pt-3 border-top">
                            <a href="usuarios.php" class="btn btn-outline-custom me-2">
                                Cancelar
                            </a>
                            <button type="submit" class="btn btn-primary-custom">
                                <i class="bi bi-save me-2"></i>Guardar Registro
                            </button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('pass');
            const toggleIcon = document.getElementById('toggleIcon');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('bi-eye-slash');
                toggleIcon.classList.add('bi-eye');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('bi-eye');
                toggleIcon.classList.add('bi-eye-slash');
            }
        }
        document.getElementById('rut').addEventListener('blur', function(e) {
            let rut = e.target.value.replace(/\D/g, '');
            if (rut.length >= 7) {
                let rutFmt = rut.slice(0, -1) + '-' + rut.slice(-1);
                rutFmt = rutFmt.replace(/(\d{2})(\d{3})(\d{3})/, '$1.$2.$3');
                e.target.value = rutFmt;
            }
        });
    </script>
</body>
</html>