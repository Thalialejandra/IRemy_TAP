<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['usuario_rut']) || $_SESSION['usuario_rol'] != 1) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Recibir y sanitizar datos (Evitar inyección SQL básica)
    $rut = $conexion->real_escape_string($_POST['rut']);
    $nombres = $conexion->real_escape_string($_POST['nombres']);
    $apellidos = $conexion->real_escape_string($_POST['apellidos']);
    $rol = $conexion->real_escape_string($_POST['rol']); // 1 o 2
    $email = $conexion->real_escape_string($_POST['email']);
    $telefono = $conexion->real_escape_string($_POST['telefono']);
    $password = $conexion->real_escape_string($_POST['password']);
    
    // Estado por defecto al crear = 1 (Activo)
    $estado_cuenta = 1;
    $check_sql = "SELECT rut_usuario FROM usuario WHERE rut_usuario = '$rut'";
    $check_result = $conexion->query($check_sql);

    if ($check_result->num_rows > 0) {
        echo "<script>
                alert('Error: El RUT ingresado ya se encuentra registrado en el sistema.');
                window.history.back();
              </script>";
        exit();
    }

    //  Inserción en Base de Datos
    $sql = "INSERT INTO usuario (rut_usuario, nombres, apellidos, password, email, telefono, id_rol, estado_cuenta) 
            VALUES ('$rut', '$nombres', '$apellidos', '$password', '$email', '$telefono', '$rol', '$estado_cuenta')";

    if ($conexion->query($sql) === TRUE) {
        echo "<script>
                alert('Colaborador registrado exitosamente.');
                window.location.href = 'usuarios.php';
              </script>";
    } else {
        echo "<script>
                alert('Error crítico al registrar: " . $conexion->error . "');
                window.history.back();
              </script>";
    }

} else {
    header("Location: usuarios.php");
    exit();
}
?>