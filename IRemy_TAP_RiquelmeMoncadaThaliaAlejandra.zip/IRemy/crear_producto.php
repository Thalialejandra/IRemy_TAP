<?php
session_start();
if (!isset($_SESSION['usuario_rut']) || $_SESSION['usuario_rol'] != 1) { header("Location: dashboard.php"); exit(); }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nuevo producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style> body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding-top: 2rem; } .card-glass { background: rgba(255,255,255,0.98); border-radius: 12px; padding: 2rem; max-width: 600px; margin: auto; } </style>
</head>
<body>
    <div class="container">
        <div class="card-glass">
            <h4 class="mb-4">Nuevo Producto</h4>
            <form action="guardar_producto.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">Nombre</label>
                    <input type="text" class="form-control" name="nombre" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Descripción</label>
                    <textarea class="form-control" name="descripcion"></textarea>
                </div>
                <div class="row">
                    <div class="col-6 mb-3">
                        <label class="form-label">Stock Inicial</label>
                        <input type="number" class="form-control" name="stock" required min="0">
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label">Precio</label>
                        <input type="number" class="form-control" name="precio" min="0">
                    </div>
                </div>
                <button type="submit" class="btn btn-dark w-100">Guardar</button>
                <a href="inventario.php" class="btn btn-link w-100 mt-2">Cancelar</a>
            </form>
        </div>
    </div>
</body>
</html>