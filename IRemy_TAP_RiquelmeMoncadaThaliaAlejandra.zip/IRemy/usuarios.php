<?php
session_start();
require 'conexion.php';

// 1. Validaciones de seguridad
if (!isset($_SESSION['usuario_rut'])) {
    header("Location: index.php");
    exit();
}

if ($_SESSION['usuario_rol'] != 1) {
    header("Location: dashboard.php");
    exit();
}

// 2. Consulta SQL
$sql = "SELECT u.rut_usuario, u.nombres, u.apellidos, u.email, u.estado_cuenta, r.nombre_rol 
        FROM usuario u 
        INNER JOIN rol r ON u.id_rol = r.id_rol";

$resultado = $conexion->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión Colaboradores - IRemy</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .card-glass {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 12px; 
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            padding: 2rem;
            margin-top: 2rem;
            margin-bottom: 2rem;
        }

        .table-hover tbody tr:hover {
            background-color: #f8f9fa;
        }
        
        .table thead th {
            font-weight: 600;
            color: #555;
            border-bottom: 2px solid #eee;
            background: transparent;
        }

        /* Botones de acción minimalistas */
        .btn-icon {
            border: 1px solid #dee2e6;
            color: #495057;
            background: white;
            padding: 0.25rem 0.5rem;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .btn-icon:hover {
            background-color: #e9ecef;
            color: #212529;
            border-color: #adb5bd;
        }

        /* Estado "Activo" Sutil */
        .badge-subtle-success {
            background-color: #d1e7dd;
            color: #0f5132;
            border: 1px solid #badbcc;
        }
        
        /* Estado "Inactivo" Sutil */
        .badge-subtle-danger {
            background-color: #f8d7da;
            color: #842029;
            border: 1px solid #f5c2c7;
        }
        
        /* Ajuste de badges */
        .badge {
            font-weight: 500;
            padding: 0.5em 0.8em;
            letter-spacing: 0.3px;
        }

        .btn-primary-custom {
            background-color: #4a5568; /* Un gris azulado profesional */
            border-color: #4a5568;
            color: white;
        }
        .btn-primary-custom:hover {
            background-color: #2d3748;
            border-color: #2d3748;
        }

    </style>
</head>
<body>

    <nav class="navbar navbar-dark bg-transparent pt-3 px-4">
        <a class="btn btn-outline-light btn-sm" href="dashboard.php">
            <i class="bi bi-arrow-left"></i> Volver
        </a>
        <span class="text-white fw-light ms-3" style="letter-spacing: 1px;">RRHH / GESTIÓN DE PERSONAL IREMY</span>
    </nav>

    <div class="container">
        
        <div class="card-glass">
            
            <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                <h5 class="text-secondary fw-bold mb-0">
                    <i class="bi bi-people me-2"></i>Lista colaboradores
                </h5>
                <a href="crear_usuario.php" class="btn btn-primary-custom btn-sm">
                    <i class="bi bi-plus-lg me-1"></i>Nuevo Registro
                </a>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>RUT</th>
                            <th>Nombres</th>
                            <th>Apellidos</th>
                            <th>Rol Asignado</th>
                            <th>Correo Corporativo</th>
                            <th class="text-center">Estado</th>     
                            <th class="text-end">Gestión</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php if ($resultado->num_rows > 0): ?>
                            <?php while($fila = $resultado->fetch_assoc()): ?>
                                <tr>
                                    <td class="fw-bold text-secondary"><?php echo $fila['rut_usuario']; ?></td>
                                    <td><?php echo $fila['nombres']; ?></td>
                                    <td><?php echo $fila['apellidos']; ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border">
                                            <?php echo $fila['nombre_rol']; ?>
                                        </span>
                                    </td>
                                    <td class="text-muted small"><?php echo $fila['email']; ?></td>
                                    
                                    <td class="text-center">
                                        <?php if($fila['estado_cuenta'] == 1): ?>
                                            <span class="badge badge-subtle-success rounded-pill">
                                                Activo
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-subtle-danger rounded-pill">
                                                Inactivo
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="text-end">
                                        <a href="editar_usuario.php?rut=<?php echo $fila['rut_usuario']; ?>" 
                                           class="btn btn-icon btn-sm" 
                                           title="Modificar Datos">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        
                                        <?php if($fila['rut_usuario'] != $_SESSION['usuario_rut']): ?>
                                            <a href="eliminar_usuario.php?rut=<?php echo $fila['rut_usuario']; ?>" 
                                               class="btn btn-icon btn-sm ms-1" 
                                               title="Cambiar Estado"
                                               onclick="return confirm('¿Confirma cambiar el estado de este colaborador?');">
                                                <i class="bi bi-person-slash"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-5">
                                    <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                    No se encontraron registros en el sistema.
                                </td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>