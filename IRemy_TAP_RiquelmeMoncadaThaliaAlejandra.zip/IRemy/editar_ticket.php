<?php
session_start();
require 'conexion.php';
if (!isset($_SESSION['usuario_rut'])) { header("Location: index.php"); exit(); }

// Validar ID
if (!isset($_GET['id'])) { header("Location: tickets.php"); exit(); }
$id_ticket = $_GET['id'];
$sql = "SELECT * FROM ticket WHERE id_ticket = $id_ticket";
$res = $conexion->query($sql);
$ticket = $res->fetch_assoc();
$clientes = $conexion->query("SELECT rut_cliente, nombres FROM cliente");
$tecnicos = $conexion->query("SELECT rut_usuario, nombres FROM usuario WHERE estado_cuenta=1");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Ticket #<?php echo $id_ticket; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding-top: 2rem; }
        .card-glass { background: rgba(255, 255, 255, 0.98); border-radius: 12px; padding: 2rem; max-width: 800px; margin: auto; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card-glass">
            
            <div class="d-flex justify-content-between mb-4">
                <h4 class="fw-bold">Gestionar ticket #<?php echo $ticket['id_ticket']; ?></h4>
                <span class="text-muted">Fecha: <?php echo $ticket['fecha_creacion']; ?></span>
            </div>
            
            <form action="actualizar_ticket.php" method="POST">
                <input type="hidden" name="id_ticket" value="<?php echo $ticket['id_ticket']; ?>">

                <div class="row g-3">
                    
                    <div class="col-12">
                        <label class="form-label fw-bold">Descripción</label>
                        <textarea class="form-control" name="descripcion" rows="5"><?php echo $ticket['descripcion_falla']; ?></textarea>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Estado actual</label>
                        <select class="form-select border-primary" name="estado">
                            <option value="Pendiente" <?php if($ticket['estado']=='Pendiente') echo 'selected'; ?>> Pendiente</option>
                            <option value="En Proceso" <?php if($ticket['estado']=='En Proceso') echo 'selected'; ?>> En Proceso</option>
                            <option value="Finalizado" <?php if($ticket['estado']=='Finalizado') echo 'selected'; ?>> Finalizado</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Técnico responsable</label>
                        <select class="form-select" name="rut_tecnico">
                            <?php while($t = $tecnicos->fetch_assoc()): ?>
                                <option value="<?php echo $t['rut_usuario']; ?>" <?php if($t['rut_usuario']==$ticket['rut_tecnico']) echo 'selected'; ?>>
                                    <?php echo $t['nombres']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                <div class="d-flex justify-content-end mt-4">
                    <a href="tickets.php" class="btn btn-outline-secondary me-2">Volver</a>
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>