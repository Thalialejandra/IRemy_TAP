<?php
session_start();
require 'conexion.php';
if (!isset($_SESSION['usuario_rut']) || $_SESSION['usuario_rol'] != 1) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $rut = $conexion->real_escape_string($_POST['rut']);
    $nombres = $conexion->real_escape_string($_POST['nombres']);
    $apellidos = $conexion->real_escape_string($_POST['apellidos']);
    $rol = $conexion->real_escape_string($_POST['rol']);
    $email = $conexion->real_escape_string($_POST['email']);
    $telefono = $conexion->real_escape_string($_POST['telefono']);
    $estado = $conexion->real_escape_string($_POST['estado_cuenta']);
    $password_nueva = $conexion->real_escape_string($_POST['password']);

    // Lógica de Actualización
    if (empty($password_nueva)) {
        $sql = "UPDATE usuario SET 
                nombres = '$nombres',
                apellidos = '$apellidos',
                id_rol = '$rol',
                email = '$email',
                telefono = '$telefono',
                estado_cuenta = '$estado'
                WHERE rut_usuario = '$rut'";
    } else {
        $sql = "UPDATE usuario SET 
                nombres = '$nombres',
                apellidos = '$apellidos',
                id_rol = '$rol',
                email = '$email',
                telefono = '$telefono',
                estado_cuenta = '$estado',
                password = '$password_nueva'
                WHERE rut_usuario = '$rut'";
    }
    if ($conexion->query($sql) === TRUE) {
        echo "<script>
                alert('Datos del colaborador actualizados correctamente.');
                window.location.href = 'usuarios.php';
              </script>";
    } else {
        echo "<script>
                alert('Error al actualizar: " . $conexion->error . "');
                window.history.back();
              </script>";
    }

} else {
    header("Location: usuarios.php");
    exit();
}
?>