<?php
session_start();
require 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id = $_POST['id_ticket'];
    $desc = $conexion->real_escape_string($_POST['descripcion']);
    $estado = $conexion->real_escape_string($_POST['estado']);
    $tecnico = $conexion->real_escape_string($_POST['rut_tecnico']);

    $sql = "UPDATE ticket SET 
            descripcion_falla = '$desc',
            estado = '$estado',
            rut_tecnico = '$tecnico'
            WHERE id_ticket = $id";

    if ($conexion->query($sql) === TRUE) {
        echo "<script>alert('Ticket actualizado.'); window.location.href='tickets.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conexion->error . "'); window.history.back();</script>";
    }

} else {
    header("Location: tickets.php");
}
?>