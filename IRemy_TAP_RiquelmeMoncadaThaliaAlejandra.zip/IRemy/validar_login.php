<?php
session_start();
require 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $rut = $conexion->real_escape_string($_POST['rut_usuario']);
    $pass = $conexion->real_escape_string($_POST['password']);

    // Buscar al usuario por RUT
    $sql = "SELECT * FROM usuario WHERE rut_usuario = '$rut'";
    $resultado = $conexion->query($sql);

    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();

        if ($pass === $usuario['password']) {
            
            if ($usuario['estado_cuenta'] == 1) {
                
                $_SESSION['usuario_rut'] = $usuario['rut_usuario'];
                $_SESSION['usuario_nombre'] = $usuario['nombres'];
                $_SESSION['usuario_rol'] = $usuario['id_rol']; // 1=Admin, 2=Técnico

                // Redirigir al Dashboard
                header("Location: dashboard.php");
                exit();

            } else {
                // Cuenta desactivada
                echo "<script>
                        alert('Acceso Denegado: Su cuenta está inactiva. Contacte al Administrador.');
                        window.location.href = 'index.php';
                      </script>";
            }

        } else {
            // Contraseña incorrecta
            echo "<script>
                    alert('Error: Contraseña incorrecta.');
                    window.location.href = 'index.php';
                  </script>";
        }

    } else {
        // Usuario no existe
        echo "<script>
                alert('Error: Usuario no encontrado.');
                window.location.href = 'index.php';
              </script>";
    }

} else {
    header("Location: index.php");
}
?>