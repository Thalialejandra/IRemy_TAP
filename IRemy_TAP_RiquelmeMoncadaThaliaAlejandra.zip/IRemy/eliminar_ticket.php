<?php
session_start();
require 'conexion.php';

// Solo admin puede borrar
if ($_SESSION['usuario_rol'] != 1) {
    echo "<script>alert('Acceso denegado'); window.location.href='tickets.php';</script>";
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    if ($conexion->query("DELETE FROM ticket WHERE id_ticket = $id")) {
        echo "<script>alert('Ticket eliminado.'); window.location.href='tickets.php';</script>";
    } else {
        echo "<script>alert('Error al eliminar.'); window.history.back();</script>";
    }
}
?>