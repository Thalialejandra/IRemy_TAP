<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Clave - Sistema IRemy</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px 0;
        }
        
        .card-aviso {
            width: 100%;
            max-width: 450px;
            padding: 2.5rem;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            text-align: center;
        }

        .icon-lock {
            font-size: 4rem;
            color: #764ba2;
            margin-bottom: 1rem;
        }

        .btn-volver {
            background: #6c757d;
            border: none;
            border-radius: 10px;
            padding: 0.75rem;
            font-weight: 600;
            width: 100%;
            color: white;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-volver:hover {
            background: #5a6268;
            transform: translateY(-2px);
            color: white;
        }

        .info-box {
            background-color: #f8f9fa;
            border-left: 5px solid #764ba2;
            padding: 15px;
            text-align: left;
            border-radius: 5px;
            margin: 20px 0;
            font-size: 0.95rem;
            color: #555;
        }
    </style>
</head>
<body>

    <div class="card-aviso">
        
        <div class="icon-lock">
            <i class="bi bi-shield-lock"></i>
        </div>

        <h2 class="h3 fw-bold text-dark mb-3">Ups!</h2>
        
        <p class="text-muted">
            Por protocolos de seguridad interna, el restablecimiento de contraseñas es gestionado de forma centralizada.
        </p>

        <div class="info-box">
            <strong>¿Qué hacer ahora?</strong><br>
            Debe contactar directamente a la <strong>administración</strong> o enviar una solicitud por correo para el  reseteo de clave
            <br><br>
            <i class="bi bi-envelope-at me-2"></i> thalia@iremy.cl<br>
            <i class="bi bi-telephone me-2"></i> +56934458715
        </div>

        <a href="index.php" class="btn-volver">
            <i class="bi bi-arrow-left me-2"></i> Volver al Inicio
        </a>

        <div class="mt-4">
            <small class="text-muted">Sistema de Gestión Interna - IRemy</small>
        </div>

    </div>

</body>
</html>